# ComparateurPro — configuration et recette de déploiement

Cette version aligne le parcours sur la LP Ubepro, avec un `formId` ComparateurPro séparé. L’URL retenue suite à votre confirmation est **`https://www.comparateurpro.fr/assurance-consultants/`**. Le conteneur GTM retenu est **`GTM-53SH7D7F`**.

## Fonctionnalités configurées

- **Tracking d’acquisition :** lecture des paramètres UTM et alias historiques `source`/`ltm_*`; lecture des paramètres de recherche et de fragment; conservation en `sessionStorage` seulement après le consentement de la catégorie appropriée. Les UTM sont liés au consentement analytics; `gclid`, `msclkid`, `fbclid` au consentement marketing. `page_url` correspond à l’URL d’entrée et `page_referrer` n’est transmis qu’avec le consentement analytics.
- **GTM :** même ID que la LP AGV. Google Consent Mode v2 est initialisé avec refus par défaut. Le script GTM n’est chargé qu’après une préférence analytics ou marketing accordée; aucun iframe GTM noscript n’est utilisé. Les événements `formulaire_lead`/`generate_lead` ne sont poussés qu’après consentement et n’incluent pas les valeurs saisies dans le formulaire.
- **SEO/GEO :** canonical, hreflang, Open Graph/Twitter avec image 1200 × 630, données structurées Organization/WebSite/WebPage/Service/FAQ, `geo.region=FR`, zone de service France, `robots.txt`, `sitemap.xml` et `llms.txt`.
- **CRM et feuille :** mêmes URLs que dans la LP Ubepro. `CP_LP_CONSULTANTS` reste distinct de l’identifiant Ubepro. La feuille Apps Script est configurée comme destination principale et la demande n’est considérée reçue qu’après sa réponse CORS JSON `{"status":"ok"}`. L’envoi CRM `no-cors` est secondaire et son état reste explicitement `unverified` (le navigateur ne peut pas lire son HTTP status).
- **SMS :** service SMS partagé avec Ubepro et vérification obligatoire (`smsVerificationRequired: true`). Le jeton, lorsqu’il existe dans la réponse, est conservé par numéro et transmis au CRM. La réponse de vérification doit comporter un indicateur positif reconnu par `phone-verification.js` (`success: true`, `ok: true`, `status: "ok"` ou `status: "success"`).

## Actions obligatoires avant publication

1. **Vérifier la propriété et le routage de domaine.** Si le domaine ou le chemin final diffère, corriger les URL absolues dans `index.html`, `config.js`, `robots.txt`, `sitemap.xml` et `llms.txt`.
2. **Publier les fichiers d’indexation à la racine du domaine.** `robots.txt`, `sitemap.xml` et `llms.txt` doivent répondre sur `https://www.comparateurpro.fr/`, même si l’HTML de la landing est sous `/assurance-consultants/`.
3. **Vérifier le conteneur GTM partagé.** Ajouter/contrôler des déclencheurs qui distinguent `form_id=CP_LP_CONSULTANTS`; vérifier les exigences de consentement Analytics/Ads de chaque tag. Le partage de conteneur peut mélanger les statistiques des deux LP si les filtres ne sont pas faits.
4. **Recetter les contrats d’API sur un environnement de test.** Confirmer que l’Apps Script autorise CORS pour le domaine ComparateurPro, accepte le schéma envoyé et renvoie exactement `{"status":"ok"}` après écriture durable. Vérifier le format réel de réponse SMS, le jeton, le délai, les erreurs 422/410/429 et le rattachement du numéro au jeton côté CRM.
5. **Confirmer le CRM.** `no-cors` ne permet pas de prouver que le CRM a stocké le lead. Pour un accusé CRM vérifiable, activer CORS côté API ou passer par un endpoint serveur/proxy maîtrisé. Sinon, suivre les rejets et reprises dans le CRM côté serveur; la feuille reste la destination qui autorise le message de succès.
6. **Publier les pages légales réellement validées.** Le pied de page pointe maintenant vers `/mentions-legales/` et `/politique-de-confidentialite/`, mais ces pages ne sont pas incluses dans ce ZIP. Ajouter l’entité juridique, les coordonnées, les destinataires de la demande, les finalités/durées, les droits, les partenaires et les mentions d’intermédiation d’assurance applicables. Vérifier les deux URLs avant ouverture au public.
7. **Tester sans données personnelles réelles en préproduction.** La vérification SMS envoie de vrais SMS si l’API pointe sur la production; ne pas cliquer sur « Recevoir le code » sur le site public pour une simple vérification de déploiement.

## Recette de tracking et formulaire

- Avec consentement refusé : pas de requête vers `googletagmanager.com`; les valeurs de tracking ne sont ni conservées ni transmises.
- Avec analytics accepté seulement : UTM, URL d’entrée et référent peuvent être transmis; aucun identifiant publicitaire ne doit être renseigné.
- Avec marketing accepté seulement : identifiants de clic autorisés; URL et UTM analytics restent vides.
- Avec consentement révoqué : Consent Mode est mis à jour et les valeurs optionnelles stockées sont purgées.
- Vérifier `window.comparateurproTracking.inspect()` dans la console de recette; il n’affiche que l’URL et les paramètres de tracking, jamais les champs personnels.
- Soumettre un lead de recette : l’interface ne confirme la demande que si la feuille répond `status: "ok"`. `window.comparateurproLead.lastResults` indique les états de la feuille et du CRM.
- Tester téléphone français au format `06…`/`07…`, ainsi que les entrées `+33`/`0033`; le numéro transmis est normalisé au format national.

## Limite de validation

La configuration du code a été vérifiée statiquement. Aucun SMS, lead, requête CRM, requête Apps Script ou hit GTM n’a été envoyé à un service de production pendant la préparation de cette version. Les points 1 à 7 ci-dessus restent une recette nécessaire avant lancement.
