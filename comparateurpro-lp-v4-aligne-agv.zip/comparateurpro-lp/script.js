/* ============================================================
   ComparateurPro — LP V3
   Sections : configuration → suivi (UTM, consentement) → en-tête et
   révélations → formulaire en 2 étapes → validation → envoi
   (Google Sheet + CRM) → succès → liens et sticky CTA
   ============================================================ */
(function () {
  'use strict';

  document.documentElement.classList.add('js');

  var CONF = Object.assign({
    formId: 'CP_LP_CONSULTANTS',
    siteUrl: 'https://www.comparateurpro.fr/',
    pageUrl: 'https://www.comparateurpro.fr/assurance-consultants/',
    gtmId: 'GTM-53SH7D7F',
    sheetUrl: '',
    primaryDestination: 'sheet',
    crmUrl: '',
    crmMode: 'cors',
    smsApiUrl: '',
    smsVerificationRequired: true,
    domaine: 'comparateurpro',
    consentTextVersion: '',
    debug: false
  }, window.COMPARATEURPRO_CONFIG || {});

  var TIMEOUT_MS = 8000;
  var TRACKING_KEY = 'cp_tracking_v1';
  var TRACKING_PAGE_KEY = 'cp_tracking_page_url_v1';
  var MARKETING_KEYS = ['gclid', 'msclkid', 'fbclid'];
  var TRACKING_FIELDS = [
    { key: 'source', aliases: ['source', 'utm_source', 'ltm_source'] },
    { key: 'categorie', aliases: ['categorie', 'utm_category', 'ltm_category', 'category'] },
    { key: 'user', aliases: ['user', 'utm_user', 'ltm_user'] },
    { key: 'utm_source', aliases: ['utm_source', 'ltm_source', 'source'] },
    { key: 'utm_medium', aliases: ['utm_medium', 'medium'] },
    { key: 'utm_campaign', aliases: ['utm_campaign', 'campaign'] },
    { key: 'utm_content', aliases: ['utm_content', 'content'] },
    { key: 'utm_term', aliases: ['utm_term', 'term'] },
    { key: 'utm_id', aliases: ['utm_id', 'campaign_id'] },
    { key: 'utm_category', aliases: ['utm_category', 'ltm_category', 'categorie', 'category'] },
    { key: 'utm_user', aliases: ['utm_user', 'ltm_user', 'user'] },
    { key: 'ltm_source', aliases: ['ltm_source', 'utm_source', 'source'] },
    { key: 'ltm_category', aliases: ['ltm_category', 'utm_category', 'categorie', 'category'] },
    { key: 'ltm_typ', aliases: ['ltm_typ', 'utm_typ', 'typ'] },
    { key: 'ltm_user', aliases: ['ltm_user', 'utm_user', 'user'] },
    { key: 'gclid', aliases: ['gclid'] },
    { key: 'msclkid', aliases: ['msclkid'] },
    { key: 'fbclid', aliases: ['fbclid'] }
  ];
  var ENTRY_URL = typeof window.__CP_ENTRY_URL__ === 'string' ? window.__CP_ENTRY_URL__ : window.location.href;
  var entryPageUrl = '';

  function log() { if (CONF.debug && window.console) console.log.apply(console, ['[comparateurpro]'].concat([].slice.call(arguments))); }

  /* === UTILITAIRES === */
  function clean(value, max) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim().slice(0, max || 500).replace(/[<>]/g, '');
  }
  function digits(value) { return String(value || '').replace(/\D/g, ''); }
  function normalizeFrenchMobile(value) {
    var phone = digits(value);
    if (phone.indexOf('0033') === 0 && phone.length === 13) phone = '0' + phone.slice(4);
    else if (phone.indexOf('33') === 0 && phone.length === 11) phone = '0' + phone.slice(2);
    return phone;
  }
  function uuid() {
    try { if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID(); } catch (_) {}
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (16 * Math.random()) | 0;
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    });
  }

  /* === SUIVI : paramètres d'acquisition selon le consentement === */
  function prefs() {
    return window.__CP_COOKIE_PREFERENCES__ || { essential: true, analytics: false, marketing: false };
  }
  function analyticsOn() { return prefs().analytics === true; }
  function marketingOn() { return prefs().marketing === true; }
  function trackingOn() { return analyticsOn() || marketingOn(); }

  function readParams(search) {
    var out = {};
    try {
      new URLSearchParams(search || '').forEach(function (value, key) {
        var k = String(key).trim().toLowerCase();
        var v = clean(value, 500);
        if (k && v) out[k] = v;
      });
    } catch (_) {}
    return out;
  }

  function paramsFromUrl(rawUrl) {
    try {
      var url = new URL(rawUrl || window.location.href, window.location.href);
      var hash = url.hash.slice(1);
      var queryStart = hash.indexOf('?');
      var hashQuery = queryStart >= 0 ? hash.slice(queryStart + 1) :
        (hash.indexOf('=') >= 0 && hash.charAt(0) !== '/' ? hash : '');
      return Object.assign({}, readParams(hashQuery), readParams(url.search));
    } catch (_) { return {}; }
  }

  function loadStoredTracking() {
    try {
      var raw = window.sessionStorage.getItem(TRACKING_KEY);
      var parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch (_) { return {}; }
  }

  function allowedKey(key) {
    if (MARKETING_KEYS.indexOf(key) !== -1) return marketingOn();
    return analyticsOn();
  }

  function removeTrackingStorage() {
    try {
      window.sessionStorage.removeItem(TRACKING_KEY);
      window.sessionStorage.removeItem(TRACKING_PAGE_KEY);
    } catch (_) {}
    entryPageUrl = '';
  }

  // Capture l'URL d'entrée (recherche ou fragment) et les paramètres UTM/annonce.
  // Aucun paramètre ni URL de page n'est conservé si le consentement correspondant manque.
  function captureTracking() {
    if (!trackingOn()) {
      removeTrackingStorage();
      return {};
    }

    var stored = loadStoredTracking();
    var next = {};
    Object.keys(stored).forEach(function (key) {
      if (allowedKey(key) && typeof stored[key] === 'string') next[key] = clean(stored[key], 500);
    });

    var sources = [paramsFromUrl(ENTRY_URL), paramsFromUrl(window.location.href)];
    TRACKING_FIELDS.forEach(function (field) {
      if (!allowedKey(field.key)) return;
      for (var i = 0; i < sources.length; i += 1) {
        var alias = field.aliases.find(function (key) { return sources[i][key]; });
        if (alias) {
          next[field.key] = sources[i][alias];
          break;
        }
      }
    });

    try {
      if (Object.keys(next).length) window.sessionStorage.setItem(TRACKING_KEY, JSON.stringify(next));
      else window.sessionStorage.removeItem(TRACKING_KEY);
      if (analyticsOn()) {
        var storedPage = window.sessionStorage.getItem(TRACKING_PAGE_KEY);
        entryPageUrl = storedPage || clean(ENTRY_URL, 1000);
        if (entryPageUrl) window.sessionStorage.setItem(TRACKING_PAGE_KEY, entryPageUrl);
      } else {
        window.sessionStorage.removeItem(TRACKING_PAGE_KEY);
        entryPageUrl = '';
      }
    } catch (_) {
      entryPageUrl = analyticsOn() ? clean(ENTRY_URL, 1000) : '';
    }
    return next;
  }

  function currentTracking() {
    var stored = captureTracking();
    var out = {};
    TRACKING_FIELDS.forEach(function (field) {
      out[field.key] = allowedKey(field.key) ? (stored[field.key] || '') : '';
    });
    out.page_url = analyticsOn() ? (entryPageUrl || clean(ENTRY_URL, 1000)) : '';
    out.page_referrer = analyticsOn() ? clean(document.referrer, 1000) : '';
    out.langue = analyticsOn() ? clean(navigator.language || '', 20) : '';
    return out;
  }

  document.addEventListener('cp:consent-changed', function () { currentTracking(); });
  window.comparateurproTracking = Object.freeze({
    version: '2026-10-09.1',
    inspect: function () {
      var values = currentTracking();
      return { current_url: window.location.href, page_url: values.page_url, values: values };
    }
  });
  window.comparateurproLead = { version: '2026-10-09.1', lastResults: null };

  /* === EN-TÊTE === */
  var hdr = document.querySelector('.hdr');
  function onHdr() { if (hdr) hdr.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onHdr, { passive: true });
  onHdr();

  var reduceMotion = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false;

  /* === RÉVÉLATION AU SCROLL === */
  var rvEls = document.querySelectorAll('.hero-copy, .form-card, .why-left, .scene, .axe, .perso, .steps li, .zero, .final-in');
  rvEls.forEach(function (el) { el.classList.add('rv'); });
  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    rvEls.forEach(function (el) { io.observe(el); });
  } else {
    rvEls.forEach(function (el) { el.classList.add('on'); });
  }

  /* === FORMULAIRE === */
  var form = document.getElementById('lead-form');
  if (!form) return;

  var step1 = document.getElementById('step-1');
  var step2 = document.getElementById('step-2');
  var prog1 = document.getElementById('prog-1');
  var prog2 = document.getElementById('prog-2');
  var formCard = document.getElementById('formulaire');
  var submitBtn = document.getElementById('submit-btn');
  var submitLabel = submitBtn ? submitBtn.textContent : '';
  var formError = document.getElementById('form-error');
  var success = document.getElementById('form-success');
  var honeypot = form.querySelector('input[name="website"]');
  formCard.setAttribute('tabindex', '-1');

  function selectedCovs() {
    return Array.prototype.map.call(form.querySelectorAll('input[name="couverture"]:checked'), function (c) { return c.value; });
  }
  function selectedSituation() {
    var s = form.querySelector('input[name="situation"]:checked');
    return s ? s.value : '';
  }
  function selectedMissions() {
    return Array.prototype.map.call(form.querySelectorAll('.mis:checked'), function (m) { return m.value; });
  }

  function buildRecap() {
    document.getElementById('recap').textContent =
      'Votre demande : ' + selectedSituation() + ' · protections à regarder : ' + selectedCovs().join(', ') + '.';
  }

  function goToStep(n) {
    var focusLater = function (el) {
      window.setTimeout(function () { if (el) el.focus({ preventScroll: false }); }, reduceMotion ? 0 : 250);
    };
    if (n === 1) {
      step2.hidden = true; step1.hidden = false;
      prog1.className = 'on'; prog2.className = '';
      focusLater(form.querySelector('#pills input'));
    } else {
      buildRecap();
      step1.hidden = true; step2.hidden = false;
      prog1.className = 'done'; prog2.className = 'on';
      focusLater(document.getElementById('f-nom'));
    }
  }

  function setErr(id, input, bad) {
    var el = document.getElementById(id);
    if (el) el.hidden = !bad;
    if (input) {
      if (bad) input.setAttribute('aria-invalid', 'true');
      else input.removeAttribute('aria-invalid');
    }
    return bad;
  }

  function showFormError(message) {
    if (!formError) return;
    formError.textContent = message;
    formError.hidden = !message;
  }

  document.getElementById('next-1').addEventListener('click', function () {
    var firstBad = null;
    if (setErr('err-situation', null, !selectedSituation())) firstBad = form.querySelector('#pills input');
    if (setErr('err-couverture', null, selectedCovs().length === 0)) firstBad = firstBad || form.querySelector('.cov input');
    if (firstBad) { firstBad.focus(); return; }
    goToStep(2);
  });
  document.getElementById('back-2').addEventListener('click', function () { goToStep(1); });

  /* === VALIDATION === */
  function validateStep2() {
    var firstBad = null;
    var nom = document.getElementById('f-nom');
    if (setErr('err-nom', nom, nom.value.trim().length < 2)) firstBad = nom;
    var email = document.getElementById('f-email');
    if (setErr('err-email', email, !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim()))) firstBad = firstBad || email;
    var tel = document.getElementById('f-tel');
    var phone = normalizeFrenchMobile(tel.value);
    if (setErr('err-tel', tel, !/^0[67]\d{8}$/.test(phone))) firstBad = firstBad || tel;
    var consent = document.getElementById('f-consent');
    if (setErr('err-consent', consent, !consent.checked)) firstBad = firstBad || consent;
    return { firstBad: firstBad, phone: phone };
  }

  /* === CONSTRUCTION DE LA DEMANDE === */
  function buildLead(phone, leadId) {
    var tracking = currentTracking();
    var nom = clean(document.getElementById('f-nom').value, 120);
    var email = clean(document.getElementById('f-email').value, 160).toLowerCase();
    var ctx = clean(document.getElementById('f-ctx').value, 120);
    var missions = selectedMissions().map(function (m) { return clean(m, 160); });
    var verifiedToken = window.__CP_PHONE_TOKEN || null;
    var submittedAt = new Date().toISOString();

    return {
      form_id: CONF.formId,
      id_lead: leadId,
      submitted_at: submittedAt,
      situation: clean(selectedSituation(), 120),
      couvertures: selectedCovs().map(function (c) { return clean(c, 120); }).join(' ; '),
      contexte: ctx,
      missions: missions.join(' ; '),
      nom: nom,
      email: email,
      telephone: phone,
      mail: email,
      domaine: CONF.domaine,
      telephone_verifie: window.__CP_PHONE_VERIFIED === true,
      verification_token: verifiedToken || '',
      consentement_coordonnees: document.getElementById('f-consent').checked === true,
      consentement_telephone: document.getElementById('phone-contact-consent').checked === true,
      consentement_version: clean(CONF.consentTextVersion, 40),
      consentement_horodatage: submittedAt,
      page_url: tracking.page_url,
      page_referrer: tracking.page_referrer,
      langue: tracking.langue,
      source: tracking.source || '',
      categorie: tracking.categorie || '',
      user: tracking.user || '',
      utm_source: tracking.utm_source || '',
      utm_medium: tracking.utm_medium || '',
      utm_campaign: tracking.utm_campaign || '',
      utm_content: tracking.utm_content || '',
      utm_term: tracking.utm_term || '',
      utm_id: tracking.utm_id || '',
      utm_category: tracking.utm_category || '',
      utm_user: tracking.utm_user || '',
      ltm_source: tracking.ltm_source || '',
      ltm_category: tracking.ltm_category || '',
      ltm_typ: tracking.ltm_typ || '',
      ltm_user: tracking.ltm_user || '',
      gclid: tracking.gclid || '',
      msclkid: tracking.msclkid || '',
      fbclid: tracking.fbclid || ''
    };
  }

  /* === ENVOI === */
  function withTimeout(url, options) {
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, TIMEOUT_MS) : null;
    options.signal = controller ? controller.signal : undefined;
    return fetch(url, options).finally(function () { if (timer) clearTimeout(timer); });
  }

  function expectOk(response, label) {
    if (!response.ok) throw new Error(label + ' HTTP ' + response.status);
    return response.text().then(function (raw) {
      var json = null;
      try { json = JSON.parse(raw); } catch (_) {}
      if (!json || json.status !== 'ok') throw new Error(label + ' réponse inattendue');
      return json;
    });
  }

  function sendToSheet(lead) {
    var body = new URLSearchParams();
    Object.keys(lead).forEach(function (k) { body.set(k, typeof lead[k] === 'string' ? lead[k] : JSON.stringify(lead[k])); });
    return withTimeout(CONF.sheetUrl, {
      method: 'POST', mode: 'cors', cache: 'no-store',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: body
    }).then(function (r) { return expectOk(r, 'Sheet'); });
  }

  function sendToCrm(lead) {
    var body = JSON.stringify({ payload: { formId: CONF.formId, id: lead.id_lead, data: lead } });
    if (CONF.crmMode === 'no-cors') {
      // Pas de lecture de réponse possible : on confirme seulement que la requête est partie.
      return withTimeout(CONF.crmUrl, {
        method: 'POST', mode: 'no-cors', cache: 'no-store', keepalive: true,
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        body: body
      }).then(function () { return { state: 'unverified' }; });
    }
    return withTimeout(CONF.crmUrl, {
      method: 'POST', mode: 'cors', cache: 'no-store',
      headers: { 'Content-Type': 'application/json;charset=UTF-8' },
      body: body
    }).then(function (r) { return expectOk(r, 'CRM'); });
  }

  function waitForResult(promise, milliseconds) {
    return new Promise(function (resolve) {
      var settled = false;
      var timer = window.setTimeout(function () {
        if (!settled) { settled = true; resolve({ state: 'pending' }); }
      }, milliseconds);
      promise.then(function (value) {
        if (!settled) { settled = true; window.clearTimeout(timer); resolve(value); }
      });
    });
  }

  function send(lead) {
    if (!CONF.sheetUrl && !CONF.crmUrl) return Promise.reject(new Error('Aucun point de réception configuré'));

    var crmJob = CONF.crmUrl
      ? sendToCrm(lead).then(function (result) {
          if (result && result.state === 'unverified') return result;
          return { state: 'confirmed', response: result };
        }).catch(function (error) {
          return { state: 'error', message: error && error.message ? error.message : 'CRM indisponible' };
        })
      : Promise.resolve({ state: 'off' });

    // Apps Script/CORS est la destination de référence: succès uniquement sur son JSON status=ok.
    if (CONF.primaryDestination === 'sheet' && CONF.sheetUrl) {
      return sendToSheet(lead).then(function (sheetResponse) {
        return waitForResult(crmJob, 1200).then(function (crmResult) {
          var results = { sheet: { state: 'confirmed', response: sheetResponse }, crm: crmResult };
          if (window.comparateurproLead) window.comparateurproLead.lastResults = results;
          if (crmResult.state === 'pending') {
            crmJob.then(function (lateResult) {
              if (window.comparateurproLead) {
                window.comparateurproLead.lastResults = {
                  sheet: results.sheet,
                  crm: lateResult
                };
              }
            });
          }
          return results;
        });
      });
    }

    // Un CRM no-cors n'est jamais considéré comme un accusé d'enregistrement.
    if (CONF.primaryDestination === 'crm' && CONF.crmMode === 'cors' && CONF.crmUrl) {
      return crmJob.then(function (crmResult) {
        if (crmResult.state !== 'confirmed') throw new Error('Le CRM n’a pas confirmé l’enregistrement');
        var results = { sheet: { state: 'off' }, crm: crmResult };
        if (window.comparateurproLead) window.comparateurproLead.lastResults = results;
        return results;
      });
    }

    return Promise.reject(new Error('Aucune destination principale ne fournit un accusé vérifiable'));
  }

  function setBusy(busy) {
    if (!submitBtn) return;
    submitBtn.disabled = busy;
    if (busy) {
      submitBtn.setAttribute('aria-busy', 'true');
      submitBtn.textContent = 'Envoi en cours…';
    } else {
      submitBtn.removeAttribute('aria-busy');
      submitBtn.textContent = submitLabel;
      submitBtn.disabled = window.__CP_PHONE_READY !== true;
    }
  }

  function showSuccess(lead) {
    var ctx = lead.contexte;
    var sum = 'Vous demandez : ' + lead.couvertures + '. Situation : ' + lead.situation + '.';
    if (ctx) sum += ' Contexte : ' + ctx + '.';
    if (lead.missions) sum += ' Précisions jointes : ' + lead.missions + '.';
    document.getElementById('success-sum').textContent = sum;
    form.hidden = true;
    success.hidden = false;
    success.setAttribute('tabindex', '-1');
    success.focus();
  }

  var sending = false;
  var currentLeadId = null; // conservé entre deux tentatives : pas de doublon côté Sheet/CRM
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (sending) return;
    showFormError('');

    // Entrée dans l'étape 1 : même chemin que le bouton « Continuer » (validation incluse).
    if (step1 && !step1.hidden) { document.getElementById('next-1').click(); return; }

    // Champ piège : un robot le remplit, on fait semblant de réussir sans rien envoyer.
    if (honeypot && honeypot.value.trim() !== '') { log('honeypot'); showSuccess(buildLead('', uuid())); return; }

    var check = validateStep2();
    if (check.firstBad) { check.firstBad.focus(); return; }

    if (!window.__CP_PHONE_READY) {
      showFormError('Vérifiez votre numéro par SMS et cochez l’accord avant de valider.');
      return;
    }

    if (!CONF.sheetUrl && !CONF.crmUrl) {
      showFormError('Le formulaire n’est pas encore relié à son point de réception. Merci de réessayer plus tard.');
      return;
    }

    if (!currentLeadId) currentLeadId = uuid();
    var lead = buildLead(check.phone, currentLeadId);
    log('lead', lead);

    sending = true;
    setBusy(true);
    send(lead).then(function (delivery) {
      sending = false;
      if (window.comparateurproLead) window.comparateurproLead.lastResults = delivery;
      if (window.dataLayer && trackingOn()) {
        window.dataLayer.push({ event: 'formulaire_lead', form_id: CONF.formId });
        window.dataLayer.push({ event: 'generate_lead', form_id: CONF.formId });
      }
      showSuccess(lead);
    }).catch(function (err) {
      sending = false;
      log('échec envoi', err);
      setBusy(false);
      showFormError('Nous n’avons pas pu enregistrer votre demande. Vérifiez votre connexion puis réessayez.');
    });
  });

  /* === LIENS « ALLER AU FORMULAIRE » === */
  document.querySelectorAll('[data-goto-form]').forEach(function (a) {
    a.addEventListener('click', function () {
      window.setTimeout(function () { formCard.focus({ preventScroll: true }); }, reduceMotion ? 0 : 400);
    });
  });

  /* === STICKY CTA MOBILE === */
  var sticky = document.getElementById('sticky-cta');
  var formVisible = false;
  function onSticky() { if (sticky) sticky.hidden = !(window.scrollY > 560 && !formVisible); }
  if ('IntersectionObserver' in window && sticky) {
    new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { formVisible = en.isIntersecting; onSticky(); });
    }, { threshold: 0.08 }).observe(formCard);
  }
  window.addEventListener('scroll', onSticky, { passive: true });
  onSticky();

  currentTracking();
})();
