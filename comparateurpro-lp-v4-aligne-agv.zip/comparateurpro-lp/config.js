/*
 * ComparateurPro — configuration de production de la landing consultants.
 * Les URLs d'intégration sont les mêmes que la LP Ubepro; le formId reste distinct.
 * Confirmer les URLs du domaine et des pages juridiques avec l'équipe avant publication.
 */
window.COMPARATEURPRO_CONFIG = {
  formId: 'CP_LP_CONSULTANTS',
  siteUrl: 'https://www.comparateurpro.fr/',
  pageUrl: 'https://www.comparateurpro.fr/assurance-consultants/',
  gtmId: 'GTM-53SH7D7F',

  // Google Apps Script: endpoint de référence, attendu en CORS avec { status: "ok" }.
  sheetUrl: 'https://script.google.com/macros/s/AKfycbwrbyCb9-cAmIRPGNvnb-aM-CkhQAerrkfP3_HSw-ewmThxsn4vbZt5daaq2aOnL01a1w/exec',
  primaryDestination: 'sheet',

  // CRM HelloLead partagé avec Ubepro. En no-cors, le navigateur ne peut pas confirmer l'écriture.
  crmUrl: 'https://mc.hellolead.pro/mon_compte/api/webflow/get_information.php',
  crmMode: 'no-cors',

  // Service SMS partagé avec Ubepro.
  smsApiUrl: 'https://mc.hellolead.pro/mon_compte/api/smspartner/envoi_code_verification.php',
  smsVerificationRequired: true,

  domaine: 'comparateurpro',
  consentTextVersion: '2026-10-09-v1',
  debug: false
};
