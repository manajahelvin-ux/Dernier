# ComparateurPro — configuration et recette de déploiement

Cette version aligne le parcours sur la LP Ubepro. Le `formId` est **`LP_CONSULTANTS`**. Le CRM HelloLead et la vérification SMS sont configurés en **production**. Une soumission crée donc un lead réel et une demande de code envoie un vrai SMS. Après l’accusé de réception de la feuille, l’écran remercie la personne et annonce un contact téléphonique ou par e-mail sous 24 h. L’URL est **`https://www.comparateurpro.fr/assurance-consultants/`** et le conteneur GTM **`GTM-53SH7D7F`**.

## Fonctionnalités configurées

- **Tracking d’acquisition :** lecture des paramètres UTM et alias historiques `source`/`ltm_*`; lecture des paramètres de recherche et de fragment; conservation en `sessionStorage` seulement après le consentement de la catégorie appropriée. Les UTM sont liés au consentement analytics; `gclid`, `msclkid`, `fbclid` au consentement marketing. `page_url` correspond à l’URL d’entrée et `page_referrer` n’est transmis qu’avec le consentement analytics.
- **GTM :** même ID que la LP AGV. Google Consent Mode v2 est initialisé avec refus par défaut. Le script GTM n’est chargé qu’après une préférence analytics ou marketing accordée; aucun iframe GTM noscript n’est utilisé. Les événements `formulaire_lead`/`generate_lead` ne sont poussés qu’après consentement et n’incluent pas les valeurs saisies dans le formulaire.
- **SEO/GEO :** canonical, hreflang, Open Graph/Twitter avec image 1200 × 630, données structurées Organization/WebSite/WebPage/Service/FAQ, `geo.region=FR`, zone de service France, `robots.txt`, `sitemap.xml` et `llms.txt`.
- **CRM en production :** le formulaire pointe vers `https://mc.hellolead.pro/mon_compte/api/webflow/get_information.php`. Le `formId` est `LP_CONSULTANTS`. Le payload CRM garde les champs existants et ajoute `code_postal`, `site`, `solution`, `enjeu`, `question_1`/`reponse_1`, `question_2`/`reponse_2`, `question_3`/`reponse_3`. `site` reprend la réponse à « Vous êtes ? » (`reponse_1`), et `code_postal` est transmis une seule fois. L’envoi reste `no-cors`, donc le navigateur ne peut pas confirmer l’écriture (`unverified`).
- **Feuille :** l’endpoint Apps Script déjà configuré reste la destination principale et reçoit le même objet plat; chaque champ est envoyé une seule fois comme clé. Le succès du formulaire dépend de sa réponse CORS JSON `{"status":"ok"}`. C’est une feuille réelle : toute soumission de test y crée une ligne.
- **Vitesse d’envoi :** CRM et feuille partent en parallèle. L’écran de remerciement attend seulement l’accusé de la feuille, sans patienter pour le CRM `no-cors`; le résultat CRM se met à jour en arrière-plan.
- **SMS :** vérification activée avec `https://mc.hellolead.pro/mon_compte/api/smspartner/envoi_code_verification.php`. Le formulaire bloque l’envoi jusqu’à ce que le numéro utilisé soit vérifié et que l’accord de rappel soit donné. Chaque demande de code peut envoyer un vrai SMS; ne pas tester avec un numéro tiers. Le lead est transmis avec `telephone_verifie: true` et le jeton lié au numéro vérifié.

## Correspondance des champs transmis

Les mêmes clés sont ajoutées une seule fois à l’objet `lead`, puis envoyées au CRM de production dans `payload.data` et à la feuille comme champs `application/x-www-form-urlencoded` :

| Champ | Valeur construite depuis le formulaire |
|---|---|
| `code_postal` | Nouveau champ facultatif; vide ou code postal français de 5 chiffres. |
| `site` | Réponse sélectionnée à « Vous êtes ? », identique à `reponse_1` (ex. `Consultant indépendant`). |
| `solution` | Protections sélectionnées, séparées par ` ; `. |
| `enjeu` | Contexte sélectionné et réalités de terrain choisies. |
| `question_1` / `reponse_1` | « Vous êtes ? » / situation sélectionnée. |
| `question_2` / `reponse_2` | « Quelles assurances regarder pour vous ? » / protections sélectionnées. |
| `question_3` / `reponse_3` | « Votre contexte et votre réalité de terrain » / contexte et missions choisis. |

Les champs historiques (`situation`, `couvertures`, `contexte`, `missions`, coordonnées, consentements et tracking autorisé) restent conservés pour compatibilité. Le code postal n’est pas dupliqué, même s’il était mentionné deux fois dans la demande.

## Actions obligatoires avant publication

1. **Vérifier la propriété et le routage de domaine.** Si le domaine ou le chemin final diffère, corriger les URL absolues dans `index.html`, `config.js`, `robots.txt`, `sitemap.xml` et `llms.txt`.
2. **Publier les fichiers d’indexation à la racine du domaine.** `robots.txt`, `sitemap.xml` et `llms.txt` doivent répondre sur `https://www.comparateurpro.fr/`, même si l’HTML de la landing est sous `/assurance-consultants/`.
3. **Vérifier le conteneur GTM partagé.** Ajouter/contrôler des déclencheurs qui distinguent `form_id=LP_CONSULTANTS`; vérifier les exigences de consentement Analytics/Ads de chaque tag. Le partage de conteneur peut mélanger les statistiques des deux LP si les filtres ne sont pas faits.
4. **Valider les contrats avant toute soumission.** Confirmer que l’Apps Script autorise CORS, persiste tous les champs supplémentaires puis renvoie `{"status":"ok"}`. Vérifier que l’API SMS autorise CORS depuis le domaine, accepte `envoyer_code`/`verifier_code` et retourne un statut positif reconnu par le script; utiliser uniquement un mobile contrôlé par l’équipe. Vérifier les clés du CRM dans `payload.data` sur un lead autorisé ou repasser temporairement en préproduction. La réponse CRM `no-cors` reste illisible depuis le navigateur.
5. **Confirmer le CRM et le suivi sous 24 h.** `no-cors` ne permet pas de prouver que le CRM a stocké le lead; vérifier côté CRM qu’un lead arrive et qu’un workflow/tâche distribue l’appel ou l’e-mail dans le délai annoncé. Le texte de remerciement ne déclenche pas lui-même un appel ni un e-mail. Pour un accusé CRM vérifiable, activer CORS côté API ou passer par un endpoint serveur/proxy maîtrisé.
6. **Publier les pages légales réellement validées.** Le pied de page pointe maintenant vers `/mentions-legales/` et `/politique-de-confidentialite/`, mais ces pages ne sont pas incluses dans ce ZIP. Ajouter l’entité juridique, les coordonnées, les destinataires de la demande, les finalités/durées, les droits, les partenaires et les mentions d’intermédiation d’assurance applicables. Vérifier les deux URLs avant ouverture au public.
7. **SMS en production.** La demande de code envoie un vrai SMS. Tester uniquement sur un numéro contrôlé par l’équipe, avec accord explicite; ne jamais déclencher un SMS sur le numéro d’un prospect pendant une vérification technique.

## Recette de tracking et formulaire

- Avec consentement refusé : pas de requête vers `googletagmanager.com`; les valeurs de tracking ne sont ni conservées ni transmises.
- Avec analytics accepté seulement : UTM, URL d’entrée et référent peuvent être transmis; aucun identifiant publicitaire ne doit être renseigné.
- Avec marketing accepté seulement : identifiants de clic autorisés; URL et UTM analytics restent vides.
- Avec consentement révoqué : Consent Mode est mis à jour et les valeurs optionnelles stockées sont purgées.
- Vérifier `window.comparateurproTracking.inspect()` dans la console de recette; il n’affiche que l’URL et les paramètres de tracking, jamais les champs personnels.
- Vérifier le code postal facultatif : vide accepté, cinq chiffres acceptés (ex. `75002`), valeur non conforme bloquée.
- N’envoyer aucun lead fictif aux endpoints de production. Après une soumission réelle autorisée, l’interface confirme uniquement après `status: "ok"` de la feuille; `window.comparateurproLead.lastResults` indique l’état de la feuille et du CRM (`unverified` pour le CRM `no-cors`). Vérifier le lead côté CRM après cette soumission.
- **Attention feuille :** l’endpoint Apps Script configuré est celui de production; toute soumission (même fictive) peut y créer une ligne. Ne pas tester sans autorisation. Si une feuille de recette existe, remplacer `sheetUrl` avant les essais.
- Sur une soumission réelle autorisée (ou sur un environnement de recette avec CRM **et** feuille de test), vérifier que `payload.data` CRM et le corps Apps Script contiennent `code_postal`, `site`, `solution`, `enjeu` et les trois paires question/réponse. Ne pas conserver ni partager de capture réseau contenant des coordonnées.
- Le numéro saisi est normalisé au format national (`06…`/`07…`, `+33` ou `0033`). La validation côté client et serveur doit réussir avant l’envoi du lead; la demande de code déclenche un vrai SMS en production.

## Limite de validation

La configuration du code a été vérifiée statiquement. Aucun SMS, lead, requête CRM, requête Apps Script ou hit GTM n’a été envoyé à un service de production pendant la préparation de cette version. Les points 1 à 7 ci-dessus restent une recette nécessaire avant lancement.
