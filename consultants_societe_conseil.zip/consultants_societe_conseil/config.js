/*
 * ComparateurPro — configuration de production de la landing consultants.
 * Le formId est LP_CONSULTANTS; vérifier les endpoints avant mise en ligne.
 */
window.COMPARATEURPRO_CONFIG = {
  formId: 'LP_CONSULTANTS',
  siteUrl: 'https://www.comparateurpro.fr/',
  pageUrl: 'https://www.comparateurpro.fr/assurance-consultants/',
  gtmId: 'GTM-53SH7D7F',

  // Google Apps Script: endpoint de référence, attendu en CORS avec { status: "ok" }.
  sheetUrl: 'https://script.google.com/macros/s/AKfycbwrbyCb9-cAmIRPGNvnb-aM-CkhQAerrkfP3_HSw-ewmThxsn4vbZt5daaq2aOnL01a1w/exec',
  primaryDestination: 'sheet',

  // CRM HelloLead production demandé. Le mode no-cors ne fournit pas d'accusé lisible.
  crmUrl: 'https://mc.hellolead.pro/mon_compte/api/webflow/get_information.php',
  crmMode: 'no-cors',

  // API SMS de production; un SMS réel est envoyé lors de chaque demande de code.
  smsApiUrl: 'https://mc.hellolead.pro/mon_compte/api/smspartner/envoi_code_verification.php',
  smsVerificationRequired: true,

  domaine: 'comparateurpro',
  consentTextVersion: '2026-10-09-v1',
  debug: false
};
