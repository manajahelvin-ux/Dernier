/* ============================================================
   ComparateurPro — vérification du mobile par SMS (6 chiffres)
   - Le serveur reste la référence : le client ne fait qu'afficher.
   - Le jeton renvoyé par le serveur (si présent) est transmis avec la demande.
   - Expose window.__CP_PHONE_READY et window.__CP_PHONE_TOKEN au script principal.
   ============================================================ */
(() => {
  "use strict";

  const CONF = window.COMPARATEURPRO_CONFIG || {};
  const API_URL = String(CONF.smsApiUrl || "").trim();
  const TIMEOUT_MS = 10000;
  const SMS_REQUIRED = CONF.smsVerificationRequired !== false;
  const DEFAULT_COOLDOWN_S = 120;
  const PHONE_RE = /^0[67]\d{8}$/;
  const CODE_RE = /^\d{6}$/;

  const form = document.querySelector("#lead-form");
  if (!form) return;

  const phoneInput = form.querySelector("#f-tel");
  const sendButton = form.querySelector("#send-sms-code");
  const codePanel = form.querySelector("#sms-code-panel");
  const codeInput = form.querySelector("#sms-code");
  const verifyButton = form.querySelector("#verify-sms-code");
  const consentInput = form.querySelector("#phone-contact-consent");
  const feedback = form.querySelector("#sms-feedback");
  const countdown = form.querySelector("#sms-countdown");
  const gateHint = form.querySelector("#verification-gate-hint");
  const submitButton = form.querySelector("#submit-btn");

  if (!phoneInput || !sendButton || !codePanel || !codeInput || !verifyButton || !consentInput || !submitButton) return;

  // État exposé au script principal (qui bloque l'envoi tant que ce n'est pas prêt)
  window.__CP_PHONE_READY = false;
  window.__CP_PHONE_VERIFIED = false;
  window.__CP_PHONE_TOKEN = null;

  // Mode test : on masque tout le bloc SMS et son texte d'aide.
  const smsBlock = form.querySelector("#sms-verify");
  const telHelp = form.querySelector("#tel-help");
  if (!SMS_REQUIRED) {
    if (smsBlock) smsBlock.hidden = true;
    if (telHelp) telHelp.hidden = true;
  }

  const cooldowns = new Map();   // numéro -> { until, source }
  const verifiedPhones = new Set();
  const requestedPhones = new Set();
  let sendBusy = false;
  let verifyBusy = false;
  let timerId = null;
  let lastPhone = phoneDigits();
  let verifiedToken = null;

  // ---------- utilitaires ----------
  function phoneDigits() {
    let digits = String(phoneInput.value || "").replace(/\D/g, "");
    // +33 6… / 0033 6… -> 06…
    if (digits.startsWith("33") && digits.length === 11) digits = "0" + digits.slice(2);
    if (digits.startsWith("0033") && digits.length === 13) digits = "0" + digits.slice(4);
    return digits;
  }

  function phoneIsValid(phone = phoneDigits()) {
    return PHONE_RE.test(phone);
  }

  function formatDuration(totalSeconds) {
    const s = Math.max(0, Math.ceil(totalSeconds));
    return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  }

  function setFeedback(message, state = "info") {
    if (!feedback) return;
    feedback.textContent = message;
    feedback.hidden = !message;
    feedback.dataset.state = state;
    feedback.setAttribute("role", state === "error" ? "alert" : "status");
    feedback.setAttribute("aria-live", state === "error" ? "assertive" : "polite");
  }

  function remainingFor(phone) {
    const cooldown = cooldowns.get(phone);
    if (!cooldown) return 0;
    const remaining = Math.ceil((cooldown.until - Date.now()) / 1000);
    if (remaining <= 0) {
      cooldowns.delete(phone);
      return 0;
    }
    return remaining;
  }

  function startCooldown(phone, seconds, source = "send") {
    const duration = Math.max(0, Math.ceil(Number(seconds) || 0));
    if (!phone || duration <= 0) return syncControls();
    cooldowns.set(phone, { until: Date.now() + duration * 1000, source });
    if (timerId === null) timerId = window.setInterval(tickCooldowns, 1000);
    syncControls();
  }

  function tickCooldowns() {
    const now = Date.now();
    for (const [phone, cooldown] of cooldowns) {
      if (cooldown.until <= now) cooldowns.delete(phone);
    }
    syncControls();
    if (cooldowns.size === 0 && timerId !== null) {
      window.clearInterval(timerId);
      timerId = null;
    }
  }

  // ---------- messages d'erreur ----------
  function firstMessage(payload) {
    if (!payload || typeof payload !== "object") return "";
    for (const source of [payload, payload.data, payload.result]) {
      if (!source || typeof source !== "object") continue;
      for (const key of ["message", "msg", "detail", "error_description", "erreur", "error"]) {
        const value = source[key];
        if (typeof value === "string" && value.trim()) return value.trim();
      }
    }
    return "";
  }

  function fallbackMessage(status, action) {
    if (status === 422) {
      return action === "envoyer_code"
        ? "Saisissez un numéro mobile français de 10 chiffres, commençant par 06 ou 07."
        : "Le code saisi est incorrect. Vérifiez les 6 chiffres reçus par SMS.";
    }
    if (status === 404) return "Aucun code n’a été envoyé à ce numéro. Demandez d’abord un code.";
    if (status === 410) return "Ce code a expiré. Demandez un nouveau code.";
    if (status === 409) return "Ce code a déjà été utilisé. Demandez un nouveau code.";
    if (status === 429) return "Une nouvelle demande est trop rapide. Patientez avant de renvoyer le code.";
    if (status === 502) return "L’envoi du SMS a échoué. Vérifiez le numéro puis réessayez.";
    if (status === 0) return "Le service de vérification ne répond pas. Vérifiez votre connexion et réessayez.";
    return "Le service de vérification SMS n’a pas pu traiter la demande. Réessayez.";
  }

  function parseDelay(value) {
    if (typeof value === "number" && Number.isFinite(value) && value >= 0) return Math.ceil(value);
    const text = String(value ?? "").trim();
    if (/^\d+(\.\d+)?$/.test(text)) return Math.ceil(Number(text));
    const clock = text.match(/^(\d{1,3}):(\d{2})$/);
    if (clock) return Number(clock[1]) * 60 + Number(clock[2]);
    return null;
  }

  function getRetryDelay(payload, response) {
    const keys = ["retry_after", "retry_after_seconds", "remaining_seconds", "cooldown_seconds", "wait_seconds", "retry_in"];
    for (const source of [payload, payload?.data]) {
      if (!source || typeof source !== "object") continue;
      for (const key of keys) {
        if (source[key] !== undefined) {
          const parsed = parseDelay(source[key]);
          if (parsed !== null) return parsed;
        }
      }
    }
    const header = response?.headers?.get("Retry-After");
    if (header) {
      const parsed = parseDelay(header);
      if (parsed !== null) return parsed;
    }
    return null;
  }

  // ---------- appel réseau ----------
  async function postVerification(action, telephone, code) {
    if (!API_URL) {
      const error = new Error("La vérification SMS n’est pas encore activée. Réessayez plus tard.");
      error.status = 0;
      error.notConfigured = true;
      throw error;
    }

    const body = new URLSearchParams();
    body.set("action", action);
    body.set("telephone", telephone);
    if (code !== undefined) body.set("code", code);

    const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), TIMEOUT_MS) : null;

    let response;
    try {
      response = await fetch(API_URL, {
        method: "POST",
        mode: "cors",
        cache: "no-store",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        body,
        signal: controller ? controller.signal : undefined
      });
    } catch (networkError) {
      const error = new Error(fallbackMessage(0, action));
      error.status = 0;
      throw error;
    } finally {
      if (timer) clearTimeout(timer);
    }

    let payload = null;
    try {
      const raw = await response.text();
      payload = raw ? JSON.parse(raw) : null;
    } catch (_) {
      payload = null;
    }

    const bodyStatus = String(payload?.status || "").toLowerCase();
    const bodyFailed = payload?.success === false || payload?.ok === false ||
      ["error", "erreur", "failed", "failure", "ko", "echec", "échec"].includes(bodyStatus);

    // Une réponse 2xx sans JSON exploitable n'est PAS une validation.
    const bodyOk = payload && (payload.success === true || payload.ok === true || bodyStatus === "ok" || bodyStatus === "success");
    if (!response.ok || bodyFailed || (action === "verifier_code" && !bodyOk)) {
      const error = new Error(firstMessage(payload) || fallbackMessage(response.status, action));
      error.status = response.status;
      error.retryAfterSeconds = response.status === 429 ? getRetryDelay(payload, response) : null;
      throw error;
    }

    return { payload, message: firstMessage(payload) };
  }

  // ---------- état de l'interface ----------
  function syncSubmitGate() {
    const phone = phoneDigits();
    const verified = phoneIsValid(phone) && verifiedPhones.has(phone);
    const accepted = consentInput.checked;
    const ready = SMS_REQUIRED ? (verified && accepted) : (phoneIsValid(phone) && accepted);

    window.__CP_PHONE_VERIFIED = verified;          // vraie vérification SMS uniquement
    window.__CP_PHONE_READY = ready;                // autorisation d'envoi
    window.__CP_PHONE_TOKEN = ready && verified ? verifiedToken : null;
    // Bouton d'envoi invalide (désactivé) tant que le numéro n'est pas vérifié et l'accord donné.
    submitButton.disabled = !ready;
    submitButton.setAttribute("aria-disabled", String(!ready));

    if (gateHint) {
      if (!SMS_REQUIRED) {
        gateHint.textContent = ready
          ? "Vous pouvez envoyer votre demande."
          : "Remplissez votre numéro et cochez l’accord pour activer la demande.";
        gateHint.dataset.state = ready ? "ready" : "waiting";
      } else if (!API_URL) {
        gateHint.textContent = "Vérification SMS indisponible pour le moment.";
        gateHint.dataset.state = "waiting";
      } else if (ready) {
        gateHint.textContent = "Numéro vérifié et accord donné : vous pouvez envoyer votre demande.";
        gateHint.dataset.state = "ready";
      } else if (verified) {
        gateHint.textContent = "Cochez l’accord d’être rappelé pour activer la demande.";
        gateHint.dataset.state = "waiting";
      } else {
        gateHint.textContent = "Vérifiez votre numéro par SMS et cochez l’accord pour activer la demande.";
        gateHint.dataset.state = "waiting";
      }
    }
  }

  function syncControls() {
    const phone = phoneDigits();
    const validPhone = phoneIsValid(phone);
    const verified = validPhone && verifiedPhones.has(phone);
    const hasCode = validPhone && requestedPhones.has(phone) && !verified;
    const remaining = validPhone ? remainingFor(phone) : 0;
    const cooldown = validPhone ? cooldowns.get(phone) : null;

    codePanel.hidden = !hasCode;
    verifyButton.disabled = !hasCode || verifyBusy || sendBusy || !CODE_RE.test(codeInput.value);

    if (sendBusy) sendButton.textContent = "Envoi du code…";
    else if (verified) sendButton.textContent = "Numéro vérifié ✓";
    else if (remaining > 0) sendButton.textContent = `Renvoyer dans ${formatDuration(remaining)}`;
    else sendButton.textContent = requestedPhones.has(phone) ? "Renvoyer le code" : "Recevoir le code";

    sendButton.disabled = !API_URL || !validPhone || verified || sendBusy || verifyBusy || remaining > 0 || !consentInput.checked;

    if (countdown) {
      if (remaining > 0 && cooldown) {
        countdown.hidden = false;
        countdown.textContent = cooldown.source === "server"
          ? `Délai indiqué par le service : ${formatDuration(remaining)}.`
          : `Nouveau code possible dans ${formatDuration(remaining)}.`;
      } else {
        countdown.hidden = true;
        countdown.textContent = "";
      }
    }

    syncSubmitGate();
  }

  function handlePhoneChange() {
    const phone = phoneDigits();
    if (phone !== lastPhone) {
      lastPhone = phone;
      codeInput.value = "";
      codeInput.removeAttribute("aria-invalid");
      if (verifiedPhones.has(phone)) setFeedback("Numéro vérifié avec succès.", "success");
      else if (requestedPhones.has(phone)) setFeedback("Un code a été envoyé à ce numéro. Saisissez les 6 chiffres reçus.", "info");
      else setFeedback("", "info");
    }
    syncControls();
  }

  // ---------- événements ----------
  phoneInput.addEventListener("input", handlePhoneChange);
  phoneInput.addEventListener("change", handlePhoneChange);
  consentInput.addEventListener("change", syncControls);

  codeInput.addEventListener("input", () => {
    codeInput.value = String(codeInput.value || "").replace(/\D/g, "").slice(0, 6);
    codeInput.removeAttribute("aria-invalid");
    syncControls();
  });

  sendButton.addEventListener("click", async () => {
    const telephone = phoneDigits();
    if (!phoneIsValid(telephone)) {
      setFeedback("Saisissez un mobile français de 10 chiffres commençant par 06 ou 07.", "error");
      phoneInput.focus();
      return;
    }
    if (verifiedPhones.has(telephone) || sendBusy || verifyBusy || remainingFor(telephone) > 0) return;

    const startedAt = Date.now();
    sendBusy = true;
    codeInput.value = "";
    codeInput.removeAttribute("aria-invalid");
    setFeedback("Envoi du code SMS en cours…", "info");
    syncControls();

    try {
      const result = await postVerification("envoyer_code", telephone);
      requestedPhones.add(telephone);
      if (phoneDigits() === telephone) {
        setFeedback(result.message || "Code envoyé par SMS. Saisissez les 6 chiffres reçus.", "success");
      }
      const elapsed = Math.floor((Date.now() - startedAt) / 1000);
      startCooldown(telephone, Math.max(0, DEFAULT_COOLDOWN_S - elapsed), "send");
    } catch (error) {
      if (error.status === 429) {
        const serverDelay = Number.isFinite(error.retryAfterSeconds) ? error.retryAfterSeconds : DEFAULT_COOLDOWN_S;
        startCooldown(telephone, serverDelay, "server");
      }
      if (phoneDigits() === telephone) setFeedback(error.message || fallbackMessage(error.status, "envoyer_code"), "error");
    } finally {
      sendBusy = false;
      syncControls();
    }
  });

  verifyButton.addEventListener("click", async () => {
    const telephone = phoneDigits();
    const code = String(codeInput.value || "").trim();
    if (!phoneIsValid(telephone)) {
      setFeedback("Saisissez un mobile français valide de 10 chiffres.", "error");
      phoneInput.focus();
      return;
    }
    if (!requestedPhones.has(telephone)) {
      setFeedback("Aucun code n’a été envoyé à ce numéro. Demandez d’abord un code.", "error");
      return;
    }
    if (!CODE_RE.test(code)) {
      codeInput.setAttribute("aria-invalid", "true");
      setFeedback("Le code doit comporter exactement 6 chiffres.", "error");
      codeInput.focus();
      return;
    }
    if (verifyBusy || sendBusy) return;

    verifyBusy = true;
    setFeedback("Vérification du code en cours…", "info");
    syncControls();

    try {
      const result = await postVerification("verifier_code", telephone, code);
      verifiedPhones.add(telephone);
      // Jeton éventuel du serveur : il sera transmis avec la demande pour contrôle côté CRM.
      const p = result.payload || {};
      verifiedToken = p.token || p.verification_token || (p.data && p.data.token) || null;
      codeInput.value = "";
      codeInput.removeAttribute("aria-invalid");
      if (phoneDigits() === telephone) setFeedback("Numéro vérifié avec succès.", "success");
    } catch (error) {
      if (error.status === 404 || error.status === 409) requestedPhones.delete(telephone);
      if (error.status === 404 || error.status === 409 || error.status === 410) {
        codeInput.value = "";
        codeInput.removeAttribute("aria-invalid");
      }
      if (error.status === 422) codeInput.setAttribute("aria-invalid", "true");
      if (phoneDigits() === telephone) setFeedback(error.message || fallbackMessage(error.status, "verifier_code"), "error");
    } finally {
      verifyBusy = false;
      syncControls();
    }
  });

  syncControls();
})();
