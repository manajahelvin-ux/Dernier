/* ============================================================
   ComparateurPro — LP V3
   Sections : configuration → suivi (UTM, consentement) → en-tête et
   révélations → formulaire en 2 étapes → validation → envoi
   (Google Sheet + CRM) → succès → liens et sticky CTA
   ============================================================ */
(function () {
  'use strict';

  document.documentElement.classList.add('js');

  var CONF = Object.assign({
    formId: 'CP_LP_CONSULTANTS',
    sheetUrl: '',
    crmUrl: '',
    crmMode: 'cors',
    smsApiUrl: '',
    domaine: 'comparateurpro',
    consentTextVersion: '',
    debug: false
  }, window.COMPARATEURPRO_CONFIG || {});

  var TIMEOUT_MS = 8000;
  var TRACKING_KEY = 'cp_tracking_v1';
  var TRACKING_PAGE_KEY = 'cp_tracking_page_url_v1';
  var ANALYTICS_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'utm_id'];
  var MARKETING_KEYS = ['gclid', 'msclkid', 'fbclid'];

  function log() { if (CONF.debug && window.console) console.log.apply(console, ['[comparateurpro]'].concat([].slice.call(arguments))); }

  /* === UTILITAIRES === */
  function clean(value, max) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim().slice(0, max || 500).replace(/[<>]/g, '');
  }
  function digits(value) { return String(value || '').replace(/\D/g, ''); }
  function uuid() {
    try { if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID(); } catch (_) {}
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (16 * Math.random()) | 0;
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    });
  }

  /* === SUIVI : UTM et identifiants publicitaires, selon le consentement === */
  function prefs() {
    return window.__CP_COOKIE_PREFERENCES__ || { analytics: false, marketing: false };
  }
  function analyticsOn() { return prefs().analytics === true; }
  function marketingOn() { return prefs().marketing === true; }

  function readParams(search) {
    var out = {};
    try {
      new URLSearchParams(search || '').forEach(function (value, key) {
        var k = String(key).trim().toLowerCase();
        var v = clean(value, 500);
        if (k && v) out[k] = v;
      });
    } catch (_) {}
    return out;
  }

  function loadStoredTracking() {
    try {
      var raw = window.sessionStorage.getItem(TRACKING_KEY);
      var parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch (_) { return {}; }
  }

  function allowedKey(key) {
    if (MARKETING_KEYS.indexOf(key) !== -1) return marketingOn();
    if (ANALYTICS_KEYS.indexOf(key) !== -1) return analyticsOn();
    return false;
  }

  // Capture les paramètres d'entrée (URL), ne garde que ce que le consentement autorise.
  function captureTracking() {
    var fromUrl = readParams(window.location.search);
    var stored = loadStoredTracking();
    var next = {};
    Object.keys(stored).forEach(function (k) { if (allowedKey(k)) next[k] = clean(stored[k], 500); });
    var found = false;
    [].concat(ANALYTICS_KEYS, MARKETING_KEYS).forEach(function (k) {
      if (fromUrl[k] && allowedKey(k)) { next[k] = fromUrl[k]; found = true; }
    });
    try {
      window.sessionStorage.setItem(TRACKING_KEY, JSON.stringify(next));
      if (found && analyticsOn()) window.sessionStorage.setItem(TRACKING_PAGE_KEY, clean(window.location.href, 1000));
    } catch (_) {}
    return next;
  }

  function currentTracking() {
    var stored = captureTracking();
    var out = {};
    [].concat(ANALYTICS_KEYS, MARKETING_KEYS).forEach(function (k) { out[k] = stored[k] || ''; });
    return out;
  }

  document.addEventListener('cp:consent-changed', function () { currentTracking(); });

  /* === EN-TÊTE === */
  var hdr = document.querySelector('.hdr');
  function onHdr() { if (hdr) hdr.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onHdr, { passive: true });
  onHdr();

  var reduceMotion = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false;

  /* === RÉVÉLATION AU SCROLL === */
  var rvEls = document.querySelectorAll('.hero-copy, .form-card, .why-left, .scene, .axe, .perso, .steps li, .zero, .final-in');
  rvEls.forEach(function (el) { el.classList.add('rv'); });
  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    rvEls.forEach(function (el) { io.observe(el); });
  } else {
    rvEls.forEach(function (el) { el.classList.add('on'); });
  }

  /* === FORMULAIRE === */
  var form = document.getElementById('lead-form');
  if (!form) return;

  var step1 = document.getElementById('step-1');
  var step2 = document.getElementById('step-2');
  var prog1 = document.getElementById('prog-1');
  var prog2 = document.getElementById('prog-2');
  var formCard = document.getElementById('formulaire');
  var submitBtn = document.getElementById('submit-btn');
  var submitLabel = submitBtn ? submitBtn.textContent : '';
  var formError = document.getElementById('form-error');
  var success = document.getElementById('form-success');
  var honeypot = form.querySelector('input[name="website"]');
  formCard.setAttribute('tabindex', '-1');

  function selectedCovs() {
    return Array.prototype.map.call(form.querySelectorAll('input[name="couverture"]:checked'), function (c) { return c.value; });
  }
  function selectedSituation() {
    var s = form.querySelector('input[name="situation"]:checked');
    return s ? s.value : '';
  }
  function selectedMissions() {
    return Array.prototype.map.call(form.querySelectorAll('.mis:checked'), function (m) { return m.value; });
  }

  function buildRecap() {
    document.getElementById('recap').textContent =
      'Votre demande : ' + selectedSituation() + ' · protections à regarder : ' + selectedCovs().join(', ') + '.';
  }

  function goToStep(n) {
    var focusLater = function (el) {
      window.setTimeout(function () { if (el) el.focus({ preventScroll: false }); }, reduceMotion ? 0 : 250);
    };
    if (n === 1) {
      step2.hidden = true; step1.hidden = false;
      prog1.className = 'on'; prog2.className = '';
      focusLater(form.querySelector('#pills input'));
    } else {
      buildRecap();
      step1.hidden = true; step2.hidden = false;
      prog1.className = 'done'; prog2.className = 'on';
      focusLater(document.getElementById('f-nom'));
    }
  }

  function setErr(id, input, bad) {
    var el = document.getElementById(id);
    if (el) el.hidden = !bad;
    if (input) {
      if (bad) input.setAttribute('aria-invalid', 'true');
      else input.removeAttribute('aria-invalid');
    }
    return bad;
  }

  function showFormError(message) {
    if (!formError) return;
    formError.textContent = message;
    formError.hidden = !message;
  }

  document.getElementById('next-1').addEventListener('click', function () {
    var firstBad = null;
    if (setErr('err-situation', null, !selectedSituation())) firstBad = form.querySelector('#pills input');
    if (setErr('err-couverture', null, selectedCovs().length === 0)) firstBad = firstBad || form.querySelector('.cov input');
    if (firstBad) { firstBad.focus(); return; }
    goToStep(2);
  });
  document.getElementById('back-2').addEventListener('click', function () { goToStep(1); });

  /* === VALIDATION === */
  function validateStep2() {
    var firstBad = null;
    var nom = document.getElementById('f-nom');
    if (setErr('err-nom', nom, nom.value.trim().length < 2)) firstBad = nom;
    var email = document.getElementById('f-email');
    if (setErr('err-email', email, !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim()))) firstBad = firstBad || email;
    var tel = document.getElementById('f-tel');
    var phone = digits(tel.value);
    if (phone.indexOf('33') === 0 && phone.length === 11) phone = '0' + phone.slice(2);
    if (setErr('err-tel', tel, !/^0[67]\d{8}$/.test(phone))) firstBad = firstBad || tel;
    var consent = document.getElementById('f-consent');
    if (setErr('err-consent', consent, !consent.checked)) firstBad = firstBad || consent;
    return { firstBad: firstBad, phone: phone };
  }

  /* === CONSTRUCTION DE LA DEMANDE === */
  function buildLead(phone, leadId) {
    var tracking = currentTracking();
    var nom = clean(document.getElementById('f-nom').value, 120);
    var email = clean(document.getElementById('f-email').value, 160).toLowerCase();
    var ctx = clean(document.getElementById('f-ctx').value, 120);
    var missions = selectedMissions().map(function (m) { return clean(m, 160); });
    var verifiedToken = window.__CP_PHONE_TOKEN || null;

    var lead = {
      form_id: CONF.formId,
      id_lead: leadId,
      submitted_at: new Date().toISOString(),
      situation: clean(selectedSituation(), 120),
      couvertures: selectedCovs().map(function (c) { return clean(c, 120); }).join(' ; '),
      contexte: ctx,
      missions: missions.join(' ; '),
      nom: nom,
      email: email,
      telephone: phone,
      mail: email,
      domaine: CONF.domaine,
      telephone_verifie: window.__CP_PHONE_VERIFIED === true,
      verification_token: verifiedToken || '',
      consentement_coordonnees: true,
      consentement_telephone: document.getElementById('phone-contact-consent').checked === true,
      consentement_version: clean(CONF.consentTextVersion, 20),
      page_url: analyticsOn() ? clean(window.location.href, 500) : '',
      page_referrer: analyticsOn() ? clean(document.referrer, 500) : '',
      utm_source: tracking.utm_source || '',
      utm_medium: tracking.utm_medium || '',
      utm_campaign: tracking.utm_campaign || '',
      utm_content: tracking.utm_content || '',
      utm_term: tracking.utm_term || '',
      utm_id: tracking.utm_id || '',
      gclid: tracking.gclid || '',
      msclkid: tracking.msclkid || '',
      fbclid: tracking.fbclid || ''
    };
    return lead;
  }

  /* === ENVOI === */
  function withTimeout(url, options) {
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, TIMEOUT_MS) : null;
    options.signal = controller ? controller.signal : undefined;
    return fetch(url, options).finally(function () { if (timer) clearTimeout(timer); });
  }

  function expectOk(response, label) {
    if (!response.ok) throw new Error(label + ' HTTP ' + response.status);
    return response.text().then(function (raw) {
      var json = null;
      try { json = JSON.parse(raw); } catch (_) {}
      if (!json || json.status !== 'ok') throw new Error(label + ' réponse inattendue');
      return json;
    });
  }

  function sendToSheet(lead) {
    var body = new URLSearchParams();
    Object.keys(lead).forEach(function (k) { body.set(k, typeof lead[k] === 'string' ? lead[k] : JSON.stringify(lead[k])); });
    return withTimeout(CONF.sheetUrl, {
      method: 'POST', mode: 'cors', cache: 'no-store',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: body
    }).then(function (r) { return expectOk(r, 'Sheet'); });
  }

  function sendToCrm(lead) {
    var body = JSON.stringify({ payload: { formId: CONF.formId, id: lead.id_lead, data: lead } });
    if (CONF.crmMode === 'no-cors') {
      // Pas de lecture de réponse possible : on confirme seulement que la requête est partie.
      return withTimeout(CONF.crmUrl, {
        method: 'POST', mode: 'no-cors', cache: 'no-store', keepalive: true,
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        body: body
      }).then(function () { return { state: 'unverified' }; });
    }
    return withTimeout(CONF.crmUrl, {
      method: 'POST', mode: 'cors', cache: 'no-store',
      headers: { 'Content-Type': 'application/json;charset=UTF-8' },
      body: body
    }).then(function (r) { return expectOk(r, 'CRM'); });
  }

  function send(lead) {
    var jobs = [];
    if (CONF.sheetUrl) jobs.push(sendToSheet(lead));
    if (CONF.crmUrl) jobs.push(sendToCrm(lead));
    if (!jobs.length) return Promise.reject(new Error('Aucun point de réception configuré'));
    // Succès seulement si toutes les destinations configurées confirment.
    return Promise.all(jobs);
  }

  function setBusy(busy) {
    if (!submitBtn) return;
    submitBtn.disabled = busy;
    if (busy) {
      submitBtn.setAttribute('aria-busy', 'true');
      submitBtn.textContent = 'Envoi en cours…';
    } else {
      submitBtn.removeAttribute('aria-busy');
      submitBtn.textContent = submitLabel;
      submitBtn.disabled = window.__CP_PHONE_READY !== true;
    }
  }

  function showSuccess(lead) {
    var ctx = lead.contexte;
    var sum = 'Vous demandez : ' + lead.couvertures + '. Situation : ' + lead.situation + '.';
    if (ctx) sum += ' Contexte : ' + ctx + '.';
    if (lead.missions) sum += ' Précisions jointes : ' + lead.missions + '.';
    document.getElementById('success-sum').textContent = sum;
    form.hidden = true;
    success.hidden = false;
    success.setAttribute('tabindex', '-1');
    success.focus();
  }

  var sending = false;
  var currentLeadId = null; // conservé entre deux tentatives : pas de doublon côté Sheet/CRM
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (sending) return;
    showFormError('');

    // Entrée dans l'étape 1 : même chemin que le bouton « Continuer » (validation incluse).
    if (step1 && !step1.hidden) { document.getElementById('next-1').click(); return; }

    // Champ piège : un robot le remplit, on fait semblant de réussir sans rien envoyer.
    if (honeypot && honeypot.value.trim() !== '') { log('honeypot'); showSuccess(buildLead('', uuid())); return; }

    var check = validateStep2();
    if (check.firstBad) { check.firstBad.focus(); return; }

    if (!window.__CP_PHONE_READY) {
      showFormError('Vérifiez votre numéro par SMS et cochez l’accord avant de valider.');
      return;
    }

    if (!CONF.sheetUrl && !CONF.crmUrl) {
      showFormError('Le formulaire n’est pas encore relié à son point de réception. Merci de réessayer plus tard.');
      return;
    }

    if (!currentLeadId) currentLeadId = uuid();
    var lead = buildLead(check.phone, currentLeadId);
    log('lead', lead);

    sending = true;
    setBusy(true);
    send(lead).then(function () {
      sending = false;
      if (window.dataLayer) {
        window.dataLayer.push({ event: 'formulaire_lead', form_id: CONF.formId });
        if (marketingOn() || analyticsOn()) window.dataLayer.push({ event: 'generate_lead', form_id: CONF.formId });
      }
      showSuccess(lead);
    }).catch(function (err) {
      sending = false;
      log('échec envoi', err);
      setBusy(false);
      showFormError('Nous n’avons pas pu enregistrer votre demande. Vérifiez votre connexion puis réessayez.');
    });
  });

  /* === LIENS « ALLER AU FORMULAIRE » === */
  document.querySelectorAll('[data-goto-form]').forEach(function (a) {
    a.addEventListener('click', function () {
      window.setTimeout(function () { formCard.focus({ preventScroll: true }); }, reduceMotion ? 0 : 400);
    });
  });

  /* === STICKY CTA MOBILE === */
  var sticky = document.getElementById('sticky-cta');
  var formVisible = false;
  function onSticky() { if (sticky) sticky.hidden = !(window.scrollY > 560 && !formVisible); }
  if ('IntersectionObserver' in window && sticky) {
    new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { formVisible = en.isIntersecting; onSticky(); });
    }, { threshold: 0.08 }).observe(formCard);
  }
  window.addEventListener('scroll', onSticky, { passive: true });
  onSticky();

  currentTracking();
})();
