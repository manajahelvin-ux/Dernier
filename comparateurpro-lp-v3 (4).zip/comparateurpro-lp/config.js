/* ============================================================
   ComparateurPro — configuration des points d'intégration.
   Endpoints partagés avec la landing Ubepro (même Sheet, même CRM,
   même service SMS). Les leads sont identifiés par formId.
   ============================================================ */
window.COMPARATEURPRO_CONFIG = {
  formId: 'CP_LP_CONSULTANTS',
  // Google Sheet / Apps Script : POST form-urlencoded, réponse JSON {"status":"ok"} (CORS confirmé)
  sheetUrl: 'https://script.google.com/macros/s/AKfycbwrbyCb9-cAmIRPGNvnb-aM-CkhQAerrkfP3_HSw-ewmThxsn4vbZt5daaq2aOnL01a1w/exec',
  // CRM : POST JSON. Pas d'en-tête CORS côté serveur : envoi en 'no-cors' (accusé non lisible).
  crmUrl: 'https://mc.hellolead.pro/mon_compte/api/webflow/get_information.php',
  crmMode: 'no-cors',
  // Service SMS (CORS autorisé) : action=envoyer_code | verifier_code
  smsApiUrl: 'https://mc.hellolead.pro/mon_compte/api/smspartner/envoi_code_verification.php',
  // Identifiant de site transmis au CRM (champ « domaine »)
  domaine: 'comparateurpro',
  // Version des textes de consentement (tracée dans chaque demande)
  consentTextVersion: '2026-10-08',
  // TEST : false = la vérification SMS est masquée et désactivée.
  // À REMETTRE À true AVANT LA MISE EN LIGNE.
  smsVerificationRequired: false,
  debug: false
};
